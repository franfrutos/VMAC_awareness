# Visual Search Experiment:

This repo is dedicated to the development of a visual search task under the "Addidional Singleton" paradigm. Is created using [jspsych](https://www.jspsych.org/7.3/) and the [jspsych-psychophysics](https://jspsychophysics.hes.kyushu-u.ac.jp/) plugin. 

The task is live [here](https://franfrutos.github.io/VMAC_jspsych/).
